# Student Records Manager: Test Plan and Bug Note

**Author:** Nathanael David Sondakh  **File:** student_manager.cpp
**Build:** `g++ -std=c++17 -Wall -Wextra student_manager.cpp -o student_manager` (no warnings)

## Test Plan

Menu numbers: 1 Add, 2 View, 3 Search, 4 Sort, 5 Statistics, 6 Remove, 0 Exit.

| # | Type | Action | Input | Expected | Actual | Pass/Fail |
|---|------|--------|-------|----------|--------|-----------|
| 1 | Normal | Add | Ani, 78 | "Added Ani." | Added Ani. | Pass |
| 2 | Invalid | Add, then View | Dewi, 150 | Invalid score; nothing stored | "Invalid score. Student not added."; View says "No records yet." | Pass |
| 3 | Empty | Statistics (empty) | 5 | "No records yet." (no crash) | No records yet. | Pass |
| 4 | Normal | Search missing name | Zed | "Zed not found." | Zed not found. | Pass |
| 5 | Normal | Statistics, 3 records | Ani 78, Bima 92, Citra 55 | Avg 75.00, max 92, min 55, passing 2 of 3 | Average 75.00, Highest 92, Lowest 55, Passing 2 of 3 | Pass |
| 6 | Normal | Sort then View | same 3 records | Bima 92, Ani 78, Citra 55 | 1. Bima 92, 2. Ani 78, 3. Citra 55 | Pass |
| 7 | Normal | Remove then View | Citra | "Removed Citra."; 2 records left | Removed Citra.; list shows Ani 78, Bima 92 | Pass |
| 8 | Boundary | Add scores 0 and 100 | A 0, B 100 | Both accepted | Both added; View shows 0 and 100 | Pass |
| 9 | Boundary | Add 59 and 60, Statistics | A 59, B 60 | Avg 59.50, passing 1 of 2 | Average 59.50, Highest 60, Lowest 59, Passing 1 of 2 | Pass |
| 10 | Invalid | Add negative score | A, -5 | Rejected, nothing stored | Invalid score. Student not added.; list empty | Pass |
| 11 | Invalid | Menu number out of range | 9 | "Invalid choice." then menu again | Invalid choice. | Pass |
| 12 | Invalid | Menu letter | abc | "Invalid choice.", no infinite loop | Invalid choice., menu returns once | Pass (after fix, see bug note) |
| 13 | Invalid | Remove missing name | Zed | "Zed not found." | Zed not found. | Pass |
| 14 | Boundary | One record: Statistics and Search | Solo, 70 | Avg/max/min all 70, passing 1 of 1; search shows 70 | Average 70.00, Highest 70, Lowest 70, Passing 1 of 1; Solo has score 70. | Pass |
| 15 | Invalid | Score is text | Ani, xyz | Rejected, no crash | Invalid score. Student not added.; list empty | Pass |
| 16 | Invalid | Duplicate name | Ani 70, then Ani 80 | Second one rejected; one record | "A student named Ani already exists. Not added."; list has 1 record | Pass (after fix) |
| 17 | Normal | Sort with tied scores, then remove | A 50, B 80, C 80, D 90; sort; remove B | D 90, B 80, C 80, A 50; after remove: D 90, C 80, A 50 | Matches; every name kept its own score | Pass |

## Bug Note

**Bug:** Typing a letter at the menu (test 12, input `abc`) made the program print the menu over and over and never stop.

**How I found it:** I planned test 12 before running the program, because the slides list "menu choice is a letter" as a test. In my first version, `main()` set `choice = -1` after a failed `cin >> choice` but did not clear `cin`. I ran it with input `abc` and the screen scrolled endlessly with "Invalid choice." and the menu. With a 2 second timeout it printed about 56 million lines.

**Cause:** When `cin` fails to read an integer, it enters an error state and the letters stay in the buffer. Every later `cin >> choice` fails immediately without waiting for the user, so the do-while loop never reaches `0`.

**Fix:** I added `clearBadInput()`, which calls `cin.clear()` and then `cin.ignore(numeric_limits<streamsize>::max(), '\n')`. It is called in `main()` and in `addStudent()` (for test 15). I also added a check for end of input (`cin.eof()`) so the loop stops if the input ends. After the fix, test 12 shows one "Invalid choice." and the menu waits normally.

**Second issue found while testing (test 16):** In an early version of `addStudent()`, a duplicate name was rejected before the score was read, so the score (for example `80`) stayed in the buffer and the menu read it as a choice and printed "Invalid choice." I fixed it by reading the name and score first, then checking for a duplicate.
