# Student Records Manager

A console program in C++ that keeps student names and scores for one class in memory.
Made for Week 9 (Programming Fundamentals Integration) of Algorithms and
Object-Oriented Programming & Lab at Swiss German University.

## Features

1. Add student (score must be 0-100)
2. View all students (numbered list)
3. Search by name
4. Sort by score, high to low (bubble sort)
5. Statistics: average, highest, lowest, number passing (pass mark 60)
6. Remove student by name
0. Exit

The menu runs until you choose 0. Invalid input is rejected and does not crash the program.

## Build and run

```bash
g++ -std=c++17 -Wall -Wextra student_manager.cpp -o student_manager
./student_manager
```

On Windows: `student_manager.exe`

## Sample session

```
Choice: 1
Name: Ani
Score (0-100): 78
Added Ani.
...
Choice: 5
Average: 75.00
Highest: 92
Lowest : 55
Passing: 2 of 3
Choice: 4
Sorted.
Choice: 2
 1. Bima             92
 2. Ani              78
 3. Citra            55
```

## Design

- Two parallel vectors (`names`, `scores`) share one index. Every add, remove and
  swap changes both so they never get out of sync.
- `main()` only runs the menu (do-while + switch). Each feature is its own function.
- `findByName` returns the index or -1 and is reused by search, remove and the duplicate check.
- `PASS_MARK` is one named constant.

## Limits

- Names are one word (no spaces), case-sensitive, and must be unique.
- Data is kept in memory only, so it is lost when the program exits.

## Testing

See [TEST_PLAN_AND_BUG_NOTE.md](TEST_PLAN_AND_BUG_NOTE.md) for 17 test cases with actual
results, and the bug note.

## Author

Nathanael David Sondakh, IT Business Innovation, Swiss German University
