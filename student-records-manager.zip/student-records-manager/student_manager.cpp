/*
 * student_manager.cpp
 * Purpose : Console Student Records Manager. Keeps names and scores for one
 *           class in memory and offers add, view, search, sort, statistics
 *           and remove through a menu that runs until the user chooses Exit.
 * Author  : Nathanael David Sondakh
 * Date    : 14 November 2026
 * Course  : Algorithms and Object-Oriented Programming & Lab (Week 9)
 *
 * Design  : Two parallel vectors share one index, so names[i] and scores[i]
 *           always describe the same student. Every function that adds,
 *           removes or reorders must change BOTH vectors together.
 * Limits  : Names are single words (no spaces) and are case-sensitive.
 *           Names must be unique so that search and remove are unambiguous.
 */

#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

using namespace std;

const int PASS_MARK = 60;   // change the pass mark here only
const int MIN_SCORE = 0;
const int MAX_SCORE = 100;

// ---------------------------------------------------------------- helpers

// Prints the main menu and the choice prompt.
void showMenu() {
    cout << "\n=== Student Records Manager ===\n"
         << "1. Add student\n"
         << "2. View all\n"
         << "3. Search by name\n"
         << "4. Sort by score\n"
         << "5. Statistics\n"
         << "6. Remove student\n"
         << "0. Exit\n"
         << "Choice: ";
}

// Clears a failed cin state and throws away the rest of the bad line, so a
// letter typed instead of a number cannot make the program loop forever.
void clearBadInput() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

// Returns true when score is inside the allowed range 0-100.
bool isValidScore(int score) {
    return score >= MIN_SCORE && score <= MAX_SCORE;
}

// Returns the index of target in names, or -1 if absent.
// names  : all student names (not modified)
// target : the name to look for (exact match, case-sensitive)
int findByName(const vector<string>& names, const string& target) {
    for (size_t i = 0; i < names.size(); i++)
        if (names[i] == target) return static_cast<int>(i);
    return -1;
}

// ------------------------------------------------------------- features

// Reads one name and score and stores them if both are valid.
// names, scores : the parallel vectors (both are extended together)
void addStudent(vector<string>& names, vector<int>& scores) {
    string name;
    int score;
    cout << "Name: ";
    cin >> name;
    cout << "Score (" << MIN_SCORE << "-" << MAX_SCORE << "): ";
    if (!(cin >> score)) {          // not a number at all
        clearBadInput();
        cout << "Invalid score. Student not added.\n";
        return;
    }
    if (!isValidScore(score)) {
        cout << "Invalid score. Student not added.\n";
        return;
    }
    // Checked after both values are read so no input is left in the buffer.
    if (findByName(names, name) != -1) {
        cout << "A student named " << name << " already exists. Not added.\n";
        return;
    }
    names.push_back(name);          // keep both vectors in sync
    scores.push_back(score);
    cout << "Added " << name << ".\n";
}

// Prints every record as a numbered list, or a message if there are none.
void viewAll(const vector<string>& names, const vector<int>& scores) {
    if (names.empty()) {
        cout << "No records yet.\n";
        return;
    }
    for (size_t i = 0; i < names.size(); i++)
        cout << setw(2) << i + 1 << ". " << left << setw(15) << names[i]
             << right << setw(4) << scores[i] << "\n";
}

// Asks for a name and prints that student's score, or "not found".
void searchStudent(const vector<string>& names, const vector<int>& scores) {
    string target;
    cout << "Name to search: ";
    cin >> target;
    int idx = findByName(names, target);
    if (idx == -1) {
        cout << target << " not found.\n";
        return;
    }
    cout << target << " has score " << scores[idx] << ".\n";
}

// Bubble sort: orders both vectors by score, highest first.
// Swaps names and scores together so every pair stays matched.
void sortByScoreDescending(vector<string>& names, vector<int>& scores) {
    for (size_t pass = 0; pass + 1 < scores.size(); pass++) {
        for (size_t i = 0; i + 1 < scores.size() - pass; i++) {
            if (scores[i] < scores[i + 1]) {
                swap(scores[i], scores[i + 1]);
                swap(names[i], names[i + 1]);   // keep both vectors in sync
            }
        }
    }
    cout << "Sorted.\n";
}

// Returns the mean of scores. Caller must make sure scores is not empty.
double computeAverage(const vector<int>& scores) {
    int sum = 0;
    for (int s : scores) sum += s;
    return static_cast<double>(sum) / static_cast<double>(scores.size());
}

// Returns the highest score. Caller must make sure scores is not empty.
int findHighest(const vector<int>& scores) {
    int best = scores[0];
    for (int s : scores)
        if (s > best) best = s;
    return best;
}

// Returns the lowest score. Caller must make sure scores is not empty.
int findLowest(const vector<int>& scores) {
    int worst = scores[0];
    for (int s : scores)
        if (s < worst) worst = s;
    return worst;
}

// Returns how many scores are at or above PASS_MARK.
int countPassing(const vector<int>& scores) {
    int count = 0;
    for (int s : scores)
        if (s >= PASS_MARK) count++;
    return count;
}

// Prints average, highest, lowest and number passing.
// Checks for an empty list first so we never divide by zero.
void showStatistics(const vector<int>& scores) {
    if (scores.empty()) {
        cout << "No records yet.\n";
        return;
    }
    cout << fixed << setprecision(2);
    cout << "Average: " << computeAverage(scores) << "\n";
    cout << "Highest: " << findHighest(scores) << "\n";
    cout << "Lowest : " << findLowest(scores) << "\n";
    cout << "Passing: " << countPassing(scores) << " of " << scores.size()
         << "\n";
}

// Asks for a name and deletes that student from both vectors.
void removeStudent(vector<string>& names, vector<int>& scores) {
    string target;
    cout << "Name to remove: ";
    cin >> target;
    int idx = findByName(names, target);
    if (idx == -1) {                // always check -1 before using the index
        cout << target << " not found.\n";
        return;
    }
    names.erase(names.begin() + idx);
    scores.erase(scores.begin() + idx);
    cout << "Removed " << target << ".\n";
}

// ------------------------------------------------------------------ main

// Only coordinates: shows the menu and calls one function per choice.
int main() {
    vector<string> names;
    vector<int> scores;
    int choice = -1;

    do {
        showMenu();
        if (!(cin >> choice)) {
            if (cin.eof()) break;   // input ended, stop instead of looping
            clearBadInput();
            choice = -1;            // falls into default below
        }
        switch (choice) {
            case 1: addStudent(names, scores); break;
            case 2: viewAll(names, scores); break;
            case 3: searchStudent(names, scores); break;
            case 4: sortByScoreDescending(names, scores); break;
            case 5: showStatistics(scores); break;
            case 6: removeStudent(names, scores); break;
            case 0: cout << "Goodbye!\n"; break;
            default: cout << "Invalid choice.\n";
        }
    } while (choice != 0);

    return 0;
}
